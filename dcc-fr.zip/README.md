# foundry-dcc-de
French translation of the DCC (Dungeon Crawl Classics) system for Foundry Virtual Tabeltop.

# Installation
1. Copy this link and use it in Foundrys module manager to install the module
    
https://github.com/Neural-noise/foundry-dcc-fr/raw/main/module.json

2. Enable the module in your world settings.
3. Make sure "French" is the language in your world settings.